import React, { useEffect, useState } from "react";
import axios from "axios";

function App() {
    const [posts, setPosts] = useState([]);
    const [form, setForm] = useState({ title: "", content: "", author: "" });

    useEffect(() => {
        axios.get("http://localhost:5000/posts").then(res => setPosts(res.data));
    }, []);

    const handleSubmit = (e) => {
        e.preventDefault();
        axios.post("http://localhost:5000/posts", form).then(res => setPosts([...posts, res.data]));
    };

    return (
        <div className="container mx-auto p-4">
            <h1 className="text-3xl font-bold">Blog</h1>
            <form onSubmit={handleSubmit} className="mb-4">
                <input type="text" placeholder="Title" onChange={e => setForm({ ...form, title: e.target.value })} className="border p-2" />
                <textarea placeholder="Content" onChange={e => setForm({ ...form, content: e.target.value })} className="border p-2" />
                <input type="text" placeholder="Author" onChange={e => setForm({ ...form, author: e.target.value })} className="border p-2" />
                <button type="submit" className="bg-blue-500 text-white p-2">Post</button>
            </form>
            <ul>
                {posts.map(post => (
                    <li key={post._id} className="border p-2">
                        <h2 className="text-xl font-bold">{post.title}</h2>
                        <p>{post.content}</p>
                        <p className="text-sm text-gray-500">by {post.author}</p>
                    </li>
                ))}
            </ul>
        </div>
    );
}

export default App;